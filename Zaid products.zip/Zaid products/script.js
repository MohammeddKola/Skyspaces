// =====================
// Product Data
// =====================
const products = [
    { name: "Crew Air Freshener", price: "₹199", image: "images/Bathroom Cleaner.webp" },
    { name: "Crew Toilet Cleaner", price: "₹149", image: "images/Air Freshner.webp" },
    { name: "Crew Floor Cleaner", price: "₹299", image: "images/diversey Cleaning Chemicals.webp" },
    { name: "Crew Glass Cleaner", price: "₹179", image: "images/Household Cleaner.webp" },
    { name: "Liquid Hand Wash", price: "₹179", image: "images/Liquid Hand Wash.webp" },
    { name: "Taski Chemicals", price: "₹179", image: "images/Taski Chemicals.webp" },
    { name: "Toilet Cleaner", price: "₹65", image: "images/Toilet Cleaner.webp" },
    { name: "Crew Room Cleaner", price: "₹65", image: "images/Crew Room Cleaner.webp" }
];

// =====================
// Render Products
// =====================
function renderProducts(containerId, productArray) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = "";

    productArray.forEach((p, i) => {
        const productDiv = document.createElement("div");
        productDiv.classList.add("product");
        productDiv.setAttribute("data-index", i); // store index for modal
        productDiv.innerHTML = `
            <img src="${p.image}" alt="${p.name}">
            <h3>${p.name}</h3>
            <p>${p.price}</p>
        `;
        container.appendChild(productDiv);
    });

    attachProductClickEvents(containerId, productArray);
}

// =====================
// Attach Modal Events
// =====================
function attachProductClickEvents(containerId, productArray) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.querySelectorAll(".product").forEach(productElement => {
        productElement.addEventListener("click", () => {
            const index = productElement.getAttribute("data-index");
            openModal(productArray[index]);
        });
    });
}

// =====================
// Slider Controls
// =====================
function attachSliderButtons(sliderId, leftBtnClass, rightBtnClass) {
    const slider = document.getElementById(sliderId);
    if (!slider) return;

    const productCard = slider.querySelector(".product");
    const scrollAmount = productCard ? productCard.offsetWidth + 20 : 250;

    document.querySelector(leftBtnClass).addEventListener("click", () => {
        slider.scrollBy({ left: -scrollAmount, behavior: "smooth" });
    });

    document.querySelector(rightBtnClass).addEventListener("click", () => {
        slider.scrollBy({ left: scrollAmount, behavior: "smooth" });
    });
}

// =====================
// Modal Logic
// =====================
const modal = document.getElementById("productModal");
const modalImage = document.getElementById("modalImage");
const modalName = document.getElementById("modalName");
const modalPrice = document.getElementById("modalPrice");
const closeBtn = document.querySelector(".close");

function openModal(product) {
    modalImage.src = product.image;
    modalName.textContent = product.name;
    modalPrice.textContent = product.price;
    modal.style.display = "block";
}

// Close modal
closeBtn.addEventListener("click", () => {
    modal.style.display = "none";
});
window.addEventListener("click", (e) => {
    if (e.target === modal) {
        modal.style.display = "none";
    }
});

// =====================
// Button Actions
// =====================
document.getElementById("addToCartBtn").addEventListener("click", () => {
    alert("Added to cart!");
});
document.getElementById("buyNowBtn").addEventListener("click", () => {
    if (currentProduct) {
        window.location.href = `checkout.html?name=${encodeURIComponent(currentProduct.name)}&price=${encodeURIComponent(currentProduct.price)}&image=${encodeURIComponent(currentProduct.image)}`;
    }
});


// =====================
// Page-specific Rendering
// =====================
if (document.getElementById("home-featured-slider")) {
    renderProducts("home-featured-slider", products);
    attachSliderButtons("home-featured-slider", ".home-left-btn", ".home-right-btn");
}

if (document.getElementById("all-products")) {
    renderProducts("all-products", products);
}

if (document.getElementById("products-featured-slider")) {
    renderProducts("products-featured-slider", products);
    attachSliderButtons("products-featured-slider", ".prod-left-btn", ".prod-right-btn");
}
let currentProduct = null; // Add this near the top of your script

function openModal(product) {
    currentProduct = product; // Store selected product
    modalImage.src = product.image;
    modalName.textContent = product.name;
    modalPrice.textContent = product.price;
    modal.style.display = "block";
}
